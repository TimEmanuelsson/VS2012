﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb_2._3
{


       class Rectangle : Shape      
    {

        public double Area
        {
            get
            {
                return Lenght * Width;
            }      
        }

        public double Perimeter
        {
            get
            {
                return Lenght * 2 + Width * 2;
            }
        }

        public Rectangle(double length, double widht) :base(length, widht)
        {

        }
    }
}

