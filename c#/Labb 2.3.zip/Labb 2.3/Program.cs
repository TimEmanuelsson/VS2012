﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb_2._3
{
    class Program
    {
        private static Shape CreatShape(ShapeType shapetype)
        {
          
        }


        static void Main(string[] args)
        {
            ViewMenu();
        }

        private static double ReadDoubleGreaterThanZero(string prompt)
        {
            double tal = 0;

           tal = double.Parse(Console.ReadLine());

           if (tal <= 0)
           {
               throw new AggregateException();
           }
           return tal;
        }

        private static void ViewMenu()
        {
            Console.WriteLine("0. Avsluta.");
            Console.WriteLine("1. Ellips.");
            Console.WriteLine("2. Rektangel.");
            Console.WriteLine("===========================================");
            Console.WriteLine("Ange menyval [0-2]: ");
        }

        private static void ViewShapeDetail(Shape shape)
        {

        }
    }

    public enum ShapeType
    {
        Ellipse,
        Rectangle,
    }
}
