﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb_2._3
{
    abstract class Shape
    {
        private double _length;
        private double _width;

        abstract public double Area
        {
            get
            {
                return Area;
            }
            
        }

        public double Lenght
        {
            get
            {
                return _length;
            }

            set
            {
                if (Lenght < 0)
                {
                    throw new AggregateException("Talet är för litet");
                }
            }
        }

        abstract public double Perimeter
        {
            get
            {
                return Perimeter;
            }
        }

        public double Width
        {
            get
            {
                return _width;
            }

            set
            {
                if (Width < 0)
                {
                    throw new AggregateException("Talet är för litet");
                }
            }
        }

        public override string ToString()
        {
            string value;

            value = string.Format("Längd  :     {0} \nBredd  :     {1} \nOmkrets  :     {2} \nArea  :     {3}", Lenght, Width, Perimeter, Area);

            return value;

            

        }

        protected Shape(double length, double width)
        {
            
        }
    }

}
