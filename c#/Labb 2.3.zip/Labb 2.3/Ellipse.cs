﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb_2._3
{
    class Ellipse : Shape
    {
        double a = 0;
        double b = 0;


        public double Area
        {
            get
            {
               
                a = Lenght / 2;
                b = Width / 2;

                return Math.PI * a * b;
            }

        }

        public double Perimeter
        {
            get
            {
                a = Lenght / 2;
                b = Width / 2;

                return Math.PI * Math.Sqrt(2 * a * a + 2 * b * b);
            }
        }

        public Ellipse(double length, double width) :base(length, width)
        {
            
        }

    }
}
